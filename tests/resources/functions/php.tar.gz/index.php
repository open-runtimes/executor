<?php

return function ($request, $response) {
    return $response->json([
        'payload' => $request['payload'],
        'variable' => $request['variables']['customVariable'],
        'unicode' => "Unicode magic: êä"
    ]);
};
